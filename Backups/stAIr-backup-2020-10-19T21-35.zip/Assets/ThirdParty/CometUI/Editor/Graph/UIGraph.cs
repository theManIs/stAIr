﻿using System.Linq;
using UnityEngine;
using XNode;

namespace CometUI
{
    [CreateAssetMenu(fileName = "UIGraph", menuName = "Comet UI/Graph", order = 1)]
    public class UIGraph : NodeGraph
    {
    }
}
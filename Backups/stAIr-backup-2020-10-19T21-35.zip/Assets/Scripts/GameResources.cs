﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameResources : ScriptableObject
{
    public Sprite[] Faces;
}

﻿namespace Assets.Static
{
    public enum FireRateType
    {
        Нет = 0,
        Одиночный = 1,
        Очередью = 2
    }
}
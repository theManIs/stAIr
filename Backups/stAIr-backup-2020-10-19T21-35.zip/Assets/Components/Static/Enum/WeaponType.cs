﻿namespace Assets.Static
{
    public enum WeaponType
    {
        None = 0, 
        Дробовик = 1
    }
}
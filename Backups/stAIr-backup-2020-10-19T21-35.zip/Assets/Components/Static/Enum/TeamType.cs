﻿namespace Assets.Static
{
    public enum TeamType
    {
        None = 0,
        Enemy = 1,
        Ally = 2
    }
}